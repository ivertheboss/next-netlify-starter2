import datetime
import threading
import json
import os
import winreg as reg
try:
    from playsound import playsound
    from plyer import notification
except:
    print("We have incountered an error!")
    print("Patching...")
    os.system('pip install playsound==1.2.2')
    os.system('pip install plyer')
try:
    from playsound import playsound
    from plyer import notification
except:
    print('We have encountered a persistant error.')
    print('Please contact TheColdLemonade on discord.')

def time():
    pass
time()

print('Thank you for using bulletin board Version 3')
playsound('song.wav')

spaceError = True
class bulletinBoard:
    global timeHour, timeMinute, start
    def __init__(self, maxNotes, name='bulletin board'):
        self.maxNotes = 100
        self.notes = []
        self.Nnotes = []
        self.notesTime = [' ']
        self.name = name
        self.autoload = False
        self.yes = True
    def addNotes(self):
        if len(self.notes)+len(self.Nnotes) >= self.maxNotes:
            pass
        else:
            self.notes.append(str(input('new note:')))
        self.limitNotes()

    def addNNote(self):

        if len(self.notes)+len(self.Nnotes) >= self.maxNotes:
            pass
        else:
            self.Nnotes.append(str(input('new n-note:')))
            timeTemp1 = "0"
            timeTemp2 = input('n-note time (hour):')
            timeTemp = input('n-note time (minute):')
            if len(str(timeTemp)) == 1:
                timeTemp1 = "".join((timeTemp1, str(timeTemp)))
            else:
                timeTemp1 = timeTemp
            self.notesTime.append(timeTemp2+str(timeTemp1))
        self.limitNNotes()

    def limitNotes(self):
        spaceError = True
        if len(self.notes)+len(self.Nnotes) >= self.maxNotes:
            if spaceError == True:
                print('no more space on the board!')
                self.noteToRemove = len(self.notes) -1
                del self.notes[int(self.noteToRemove)]
                spaceError = False
                self.noteToRemove = ' '
                self.console()
        else:
            print('added note!')
            self.console()

    def limitNNotes(self):
        spaceError = True
        if len(self.Nnotes) >= self.maxNotes:
            if spaceError == True:
                print('no more space on the board!')
                self.noteToRemove = len(self.Nnotes) -1
                del self.Nnotes[int(self.noteToRemove)]
                spaceError = False
                self.noteToRemove = ' '
                self.console()
        else:
            print('added note!')
            self.console()

    def console(self):
        global newCommand
        if self.yes:
            with open('notes.json', 'r+') as f:
                data = json.load(f)
                if data['auto'][0]['0']:
                    self.autoload = True
                    print('Auto load starting...')
                    self.loadSave()
        self.yes = False
        

        newCommand = input('Bulletin Board:> ')

        if newCommand == 'new note':
            self.addNotes()
        elif newCommand == 'save':
            self.saveBB()
        elif newCommand == 'add to startup':
            AddToRegistry()
            self.resetConsole()
        elif newCommand == 'bwoink':
            playsound('bwoink.wav')
            self.resetConsole()
        elif newCommand == 'auto load':
            self.autoload = True
            print("Adding...")
            self.saveBB()
            for x in self.notes:
                data["notes"].append({"0" : str(x)})
            for x in self.Nnotes:
                data["nnotes"].append({"0" : str(x)})
            for x in self.notesTime:
                data["times"].append({"0" : str(x)})
            with open('notes.json', 'w') as outfile:
                outfile.write(json.dumps(data))
            print("Saved!")
            self.resetConsole()
        elif newCommand == 'remove auto load':
            self.autoload = False
            print("Removing...")
            self.saveBB()
        elif newCommand == 'time':
            current_time = datetime.datetime.now()
            timeMinute = str(current_time.minute)
            timeHour = str(current_time.hour)
            timeTemp1 = "0"
            if len(str(timeMinute)) == 1:
                timeTemp1 = "".join((timeTemp1, str(timeMinute)))
            else:
                timeTemp1 = timeMinute
            Ntime = timeHour + timeTemp1
            print(Ntime)
            self.resetConsole()
        elif newCommand == 'read save':
            self.readSave()
        elif newCommand == 'load save':
            self.loadSave()
        elif newCommand == 'help':
            print('new note [makes a new note]')
            print('new n-note [adds a note with a notification]')
            print('remove note [removes a note]')
            print('remove n-note [removes an n-note]')
            print('display notes [displays note(s)]')
            print('time [shows current time according to python]')
            print('save [saves notes to JSON]')
            print('read save [displays note(s) saved on JSON]')
            print('load save [loads note(s) saved on JSON]')
            print('auto load [automaticly loads save]')
            print('remove auto load [stops automaticly loading save]')
            print('add to startup [makes bulletin board open when computer boots][to remove go to computer settings]')
            self.resetConsole()
        elif newCommand == 'remove note':
            self.noteToRemove = input('which note do you want to remove?')
            if self.noteToRemove == str:
                print('oops! only excepts: int')
                self.resetConsole()
            else:
                self.removeNote()
        elif newCommand == 'remove n-note':
            self.noteToRemove = input('which n-note do you want to remove?')
            if self.noteToRemove == str:
                print('oops! only excepts: int')
                self.resetConsole()
            else:
                self.removeNnote()
        elif newCommand == 'display notes':
            print('notes:',self.notes)
            print('n-notes:',self.Nnotes)
            print('n-notes times:',str(self.notesTime))
            self.resetConsole()
        elif newCommand == 'new n-note':
            current_time = datetime.datetime.now()
            timeMinute = str(current_time.minute)
            timeHour = str(current_time.hour)
            timeTemp1 = "0"
            if len(str(timeMinute)) == 1:
                timeTemp1 = "".join((timeTemp1, str(timeMinute)))
            else:
                timeTemp1 = timeMinute
            Ntime = timeHour + timeTemp1
            print('time:',Ntime,'[army time]')
            self.addNNote()
        else:
            self.resetConsole()

    def resetConsole(self):
        newCommand = ' '
        self.console()

    def removeNote(self):
        try:
            del self.notes[int(self.noteToRemove)]
            print('note removed!')
        except:
            print("Hmm, that note seems to not exist.")
        
        self.resetConsole()

    def removeNnote(self):
        try:
            del self.Nnotes[int(self.noteToRemove)]
            del self.notesTime[int(self.noteToRemove)]
            print('note removed!')
        except:
            print("Hmm, that note seems to not exist.")

        self.resetConsole()

    def saveBB(self):
        yes = False
        while not yes:
            temp = input("This will overide the current save. Do you want to continue? Y/N").capitalize()
            if temp == "Y":
                yes = True
            elif temp == "N":
                self.resetConsole()
            else:
                print("Y/N")
        if yes:
            print("Saving...")
            data = {
                "notes" : [
                ],
                "nnotes" : [
                ],
                "times" : [
                ],
                "auto" : [
                    {"0" : self.autoload}
                ]
            }
            for x in self.notes:
                data["notes"].append({"0" : str(x)})
            for x in self.Nnotes:
                data["nnotes"].append({"0" : str(x)})
            for x in self.notesTime:
                data["times"].append({"0" : str(x)})
            with open('notes.json', 'w') as outfile:
                outfile.write(json.dumps(data))
            print("Saved!")
            self.resetConsole()

    def readSave(self):
        with open('notes.json', 'r') as outfile:
            temp = json.load(outfile)
        print(temp)
        if len(temp['notes']) == 0:
            print("No save detected.")
        self.resetConsole()

    def loadSave(self):
        global start
        print("Loading...")
        with open('notes.json', 'r') as outfile:
            temp = json.load(outfile)
        for x in temp['notes']:
            self.notes.append(x['0'])
        print("Save loaded!")
        start = False
        self.yes = False
        self.resetConsole()

bltn = bulletinBoard(4)
runNotification = True
threading.Thread(target = bltn.console).start()

def AddToRegistry():
 
    # in python __file__ is the instant of
    # file path where it was executed
    # so if it was executed from desktop,
    # then __file__ will be
    # c:\users\current_user\desktop
    pth = os.path.dirname(os.path.realpath(__file__))
     
    # name of the python file with extension
    s_name="BB.py"    
     
    # joins the file name to end of path address
    address=os.path.join(pth,s_name)
     
    # key we want to change is HKEY_CURRENT_USER
    # key value is Software\Microsoft\Windows\CurrentVersion\Run
    key = reg.HKEY_CURRENT_USER
    key_value = "Software\Microsoft\Windows\CurrentVersion\Run"
     
    # open the key to make changes to
    open = reg.OpenKey(key,key_value,0,reg.KEY_ALL_ACCESS)
     
    # modify the opened key
    reg.SetValueEx(open,"any_name",0,reg.REG_SZ,address)
     
    # now close the opened key
    reg.CloseKey(open)

AddToRegistry()

def noteNotification(title, message):
    global runNotification, Ntime
    for x in bltn.notesTime:
        if x == Ntime:
            if runNotification == True:
                notification.notify(
                    title=title,
                    message=message,
                    app_icon='python icon.ico',
                    timeout=30,
                )
                runNotification = False
        else:
            runNotification = True

del bltn.notesTime[int(0)]

while True:
    time()
    current_time = datetime.datetime.now()
    timeMinute = str(current_time.minute)
    timeHour = str(current_time.hour)
    timeTemp1 = "0"
    if len(str(timeMinute)) == 1:
        timeTemp1 = "".join((timeTemp1, str(timeMinute)))
    else:
        timeTemp1 = timeMinute
    Ntime = timeHour + timeTemp1

    if len(bltn.notesTime) >= 1:
        noteNotification('N-note', 'Check your bulletin board')